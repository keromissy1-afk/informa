/**
 * INFORMA 180 — API الاشتراكات
 * -------------------------------------------------------------
 * Node.js + Express + SQLite
 *
 * الفكرة باختصار:
 *  - العميل بيسجل من checkout.html بإيميل وباسورد من اختياره  → بيتخزن كـ "طلب معلّق"
 *  - انت بتفتح admin.html وتشوف الطلبات، وتدوس ✓ على اللي دفع  → يتفعّل فوراً
 *  - العميل يدخل access.html بنفس بياناته ويشوف الفيديوهات
 *
 * الباسوردات بتتخزن مشفّرة (bcrypt) — حتى انت مش بتشوفها.
 */

require('dotenv').config();

const path = require('path');
const fs = require('fs');
const express = require('express');
const cors = require('cors');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// ============ الإعدادات ============
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || '';
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || '').toLowerCase();
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data', 'informa.db');
const DEFAULT_PLAN_DAYS = Number(process.env.PLAN_DAYS || 30);

if (!JWT_SECRET || JWT_SECRET.length < 16) {
  console.error('\n[خطأ] لازم تحط JWT_SECRET في ملف .env (32 حرف عشوائي على الأقل).');
  console.error('اعمله بالأمر ده:  node -e "console.log(require(\'crypto\').randomBytes(32).toString(\'hex\'))"\n');
  process.exit(1);
}
if (!ADMIN_EMAIL || !ADMIN_PASSWORD) {
  console.error('\n[خطأ] لازم تحط ADMIN_EMAIL و ADMIN_PASSWORD في ملف .env\n');
  process.exit(1);
}

const PLANS = {
  basic: { name: 'باقة التدريب', price: 600 },
  pro: { name: 'تدريب + تغذية', price: 1000 },
  elite: { name: 'باقة VIP', price: 1800 },
};

// ============ قاعدة البيانات ============
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS members (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    phone         TEXT NOT NULL,
    email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    plan_id       TEXT NOT NULL,
    plan_name     TEXT NOT NULL,
    price         INTEGER,
    status        TEXT NOT NULL DEFAULT 'pending',
    note          TEXT,
    created_at    TEXT NOT NULL,
    activated_at  TEXT,
    expires_at    TEXT
  );
`);

// ============ أدوات مساعدة ============
const now = () => new Date().toISOString();

function addDays(isoOrNull, days) {
  const base = isoOrNull && new Date(isoOrNull) > new Date() ? new Date(isoOrNull) : new Date();
  base.setDate(base.getDate() + days);
  return base.toISOString();
}

function isExpired(member) {
  return !!member.expires_at && new Date(member.expires_at) < new Date();
}

/** الشكل اللي بيرجع للواجهة — من غير الباسورد أبداً */
function publicMember(m) {
  return {
    id: m.id,
    name: m.name,
    phone: m.phone,
    email: m.email,
    planId: m.plan_id,
    planName: m.plan_name,
    price: m.price,
    status: isExpired(m) && m.status === 'active' ? 'expired' : m.status,
    note: m.note || '',
    createdAt: m.created_at,
    activatedAt: m.activated_at,
    expiresAt: m.expires_at,
    daysLeft: m.expires_at
      ? Math.ceil((new Date(m.expires_at) - new Date()) / 86400000)
      : null,
  };
}

const isEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const isEgyPhone = (v) => /^01[0125][0-9]{8}$/.test(v);

// حد بسيط لمنع سبام التسجيل (بدون مكتبات)
const signupHits = new Map();
function signupRateLimit(req, res, next) {
  const ip = req.ip || 'unknown';
  const windowMs = 60 * 60 * 1000;
  const max = 8;
  const hits = (signupHits.get(ip) || []).filter((t) => Date.now() - t < windowMs);
  if (hits.length >= max) {
    return res.status(429).json({ error: 'طلبات كتير في وقت قصير، حاول بعد شوية.' });
  }
  hits.push(Date.now());
  signupHits.set(ip, hits);
  next();
}

function signToken(payload, expiresIn) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn });
}

function readToken(req) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return null;
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}

function requireAdmin(req, res, next) {
  const data = readToken(req);
  if (!data || data.type !== 'admin') {
    return res.status(401).json({ error: 'مش مسموح، سجّل دخولك تاني.' });
  }
  next();
}

function requireMember(req, res, next) {
  const data = readToken(req);
  if (!data || data.type !== 'member') {
    return res.status(401).json({ error: 'مش مسموح، سجّل دخولك تاني.' });
  }
  const member = db.prepare('SELECT * FROM members WHERE id = ?').get(data.sub);
  if (!member) return res.status(401).json({ error: 'الحساب مش موجود.' });
  if (member.status !== 'active') return res.status(403).json({ error: 'الحساب مش مفعّل.', reason: member.status });
  if (isExpired(member)) return res.status(403).json({ error: 'الاشتراك خلص.', reason: 'expired' });
  req.member = member;
  next();
}

// ============ التطبيق ============
const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '64kb' }));
app.use(cors({ origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : true }));

// ---------- عام: الباقات ----------
app.get('/api/plans', (req, res) => res.json({ plans: PLANS }));

// ---------- عام: تسجيل طلب اشتراك جديد ----------
app.post('/api/signup', signupRateLimit, (req, res) => {
  const { name, phone, email, password, planId } = req.body || {};

  if (!name || String(name).trim().length < 3) return res.status(400).json({ error: 'اكتب اسمك بالكامل.' });
  if (!isEgyPhone(String(phone || '').trim())) return res.status(400).json({ error: 'رقم الموبايل غير صحيح.' });
  if (!isEmail(String(email || '').trim())) return res.status(400).json({ error: 'الإيميل غير صحيح.' });
  if (!password || String(password).length < 6) return res.status(400).json({ error: 'الباسورد لازم يكون 6 حروف على الأقل.' });
  if (!PLANS[planId]) return res.status(400).json({ error: 'الباقة غير معروفة.' });

  const cleanEmail = String(email).trim().toLowerCase();
  const existing = db.prepare('SELECT * FROM members WHERE email = ?').get(cleanEmail);

  if (existing && existing.status === 'active' && !isExpired(existing)) {
    return res.status(409).json({ error: 'الإيميل ده مفعّل بالفعل، سجّل دخولك من صفحة دخول الأعضاء.' });
  }

  const hash = bcrypt.hashSync(String(password), 10);
  const plan = PLANS[planId];

  if (existing) {
    // طلب قديم معلّق أو اشتراك خلص → نحدّثه بدل ما نرفض
    db.prepare(`
      UPDATE members SET name=?, phone=?, password_hash=?, plan_id=?, plan_name=?, price=?,
                         status='pending', created_at=?
      WHERE id=?
    `).run(String(name).trim(), String(phone).trim(), hash, planId, plan.name, plan.price, now(), existing.id);
  } else {
    db.prepare(`
      INSERT INTO members (name, phone, email, password_hash, plan_id, plan_name, price, status, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?)
    `).run(String(name).trim(), String(phone).trim(), cleanEmail, hash, planId, plan.name, plan.price, now());
  }

  res.json({ ok: true, message: 'تم استلام طلبك، هيتفعّل بعد تأكيد الدفع.' });
});

// ---------- عام: دخول العضو ----------
app.post('/api/login', (req, res) => {
  const { email, password } = req.body || {};
  const member = db.prepare('SELECT * FROM members WHERE email = ?').get(String(email || '').trim().toLowerCase());

  if (!member || !bcrypt.compareSync(String(password || ''), member.password_hash)) {
    return res.status(401).json({ error: 'الإيميل أو الباسورد غير صحيحة.' });
  }
  if (member.status === 'pending') {
    return res.status(403).json({ error: 'طلبك لسه قيد المراجعة، هيتفعّل بعد تأكيد الدفع.', reason: 'pending' });
  }
  if (member.status === 'disabled') {
    return res.status(403).json({ error: 'الحساب موقوف، تواصل معانا على واتساب.', reason: 'disabled' });
  }
  if (isExpired(member)) {
    return res.status(403).json({ error: 'اشتراكك خلص، جدّده عشان تكمل.', reason: 'expired' });
  }

  const token = signToken({ sub: member.id, type: 'member' }, '30d');
  res.json({ token, member: publicMember(member) });
});

// ---------- عضو: بياناتي (بيستخدمها videos.html) ----------
app.get('/api/me', requireMember, (req, res) => {
  res.json({ member: publicMember(req.member) });
});

// ---------- أدمن: دخول اللوحة ----------
app.post('/api/admin/login', (req, res) => {
  const { email, password } = req.body || {};
  const okEmail = String(email || '').trim().toLowerCase() === ADMIN_EMAIL;
  const okPass = String(password || '') === ADMIN_PASSWORD;
  if (!okEmail || !okPass) {
    return res.status(401).json({ error: 'الإيميل أو الباسورد غير صحيحة.' });
  }
  res.json({ token: signToken({ sub: 'admin', type: 'admin' }, '12h') });
});

// ---------- أدمن: كل الأعضاء ----------
app.get('/api/admin/members', requireAdmin, (req, res) => {
  const rows = db.prepare('SELECT * FROM members ORDER BY created_at DESC').all();
  res.json({ members: rows.map(publicMember) });
});

// ---------- أدمن: تفعيل عضو (زرار ✓) ----------
app.post('/api/admin/members/:id/activate', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const months = Math.min(Math.max(Number(req.body?.months || 1), 1), 12);
  const member = db.prepare('SELECT * FROM members WHERE id = ?').get(id);
  if (!member) return res.status(404).json({ error: 'العضو مش موجود.' });

  const expires = addDays(member.expires_at, DEFAULT_PLAN_DAYS * months);
  db.prepare(`UPDATE members SET status='active', activated_at=COALESCE(activated_at, ?), expires_at=? WHERE id=?`)
    .run(now(), expires, id);

  res.json({ member: publicMember(db.prepare('SELECT * FROM members WHERE id = ?').get(id)) });
});

// ---------- أدمن: إيقاف عضو ----------
app.post('/api/admin/members/:id/disable', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const member = db.prepare('SELECT * FROM members WHERE id = ?').get(id);
  if (!member) return res.status(404).json({ error: 'العضو مش موجود.' });
  db.prepare(`UPDATE members SET status='disabled' WHERE id=?`).run(id);
  res.json({ member: publicMember(db.prepare('SELECT * FROM members WHERE id = ?').get(id)) });
});

// ---------- أدمن: حذف عضو ----------
app.delete('/api/admin/members/:id', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const info = db.prepare('DELETE FROM members WHERE id = ?').run(id);
  if (!info.changes) return res.status(404).json({ error: 'العضو مش موجود.' });
  res.json({ ok: true });
});

// ============ الملفات الثابتة (الموقع نفسه) ============
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));

app.use((req, res) => res.status(404).json({ error: 'الصفحة مش موجودة.' }));

app.listen(PORT, () => {
  console.log(`\n✅ INFORMA 180 شغال على  http://localhost:${PORT}`);
  console.log(`   لوحة التحكم:      http://localhost:${PORT}/admin.html`);
  console.log(`   قاعدة البيانات:   ${DB_PATH}\n`);
});
