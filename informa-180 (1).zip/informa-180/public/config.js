/**
 * إعدادات الموقع — غيّرها من هنا وهي هتأثر على كل الصفحات
 */
window.INFORMA = {
  // لينك الـ API.
  // سيبها فاضية '' لو الموقع والسيرفر على نفس الدومين (الوضع الطبيعي).
  // لو حاطط الصفحات على GitHub Pages والسيرفر في مكان تاني، حط لينك السيرفر كامل:
  // apiBase: 'https://api.your-domain.com'
  apiBase: '',

  // رقم الواتساب بتاعك بصيغة دولية (بدون + وبدون صفر)
  whatsapp: '20XXXXXXXXXX', // ✏️ حط رقم واتساب حسين بصيغة دولية بدون + وبدون صفر

  // الباقات (لازم تبقى نفس اللي في server.js)
  plans: {
    basic: { name: 'باقة التدريب', price: 600 },
    pro: { name: 'تدريب + تغذية', price: 1000 },
    elite: { name: 'باقة VIP', price: 1800 },
  },
};

/** نداء موحّد للـ API */
window.api = async function api(path, { method = 'GET', body, token } = {}) {
  const res = await fetch(window.INFORMA.apiBase + path, {
    method,
    headers: {
      ...(body ? { 'Content-Type': 'application/json' } : {}),
      ...(token ? { Authorization: 'Bearer ' + token } : {}),
    },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });

  let data = {};
  try { data = await res.json(); } catch { /* رد فاضي */ }

  if (!res.ok) {
    const err = new Error(data.error || 'حصل خطأ، حاول تاني.');
    err.status = res.status;
    err.reason = data.reason;
    throw err;
  }
  return data;
};
