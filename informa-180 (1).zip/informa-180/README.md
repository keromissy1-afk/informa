# INFORMA 180 — موقع التدريب الأونلاين (حسين سيد)

موقع + API لإدارة اشتراكات التدريب الأونلاين. المتدرب بيسجّل بإيميل وباسورد من اختياره،
والطلب بيظهر في لوحة التحكم، وبضغطة ✓ واحدة بيتفعّل ويقدر يدخل على برنامجه ومكتبة التمارين.

**الاستاك:** Node.js + Express + SQLite + Tailwind

---

## طريقة الشغل

```
العميل يسجّل (checkout.html)  →  طلب "معلّق" في قاعدة البيانات
                                        ↓
                         يبعتلك إثبات الدفع على واتساب
                                        ↓
              انت تفتح admin.html وتدوس ✓ على الطلب  →  يتفعّل فوراً
                                        ↓
        العميل يدخل (access.html) بنفس بياناته  →  يشوف الفيديوهات
```

- **الباسوردات مشفّرة** في قاعدة البيانات (bcrypt) — حتى انت مش بتشوفها، والعميل بيدخل باللي هو كتبه.
- **الاشتراك بمدة**: كل تفعيل بيدي 30 يوم (تقدر تغيّرها من `.env`)، وبعدها الحساب بيقف لوحده.
  في اللوحة فيه زرار "تجديد شهر".
- **الإيقاف فوري**: أول ما توقف عضو، أول ما يفتح صفحة الفيديوهات بيترمي بره حتى لو كان داخل.

---

## التشغيل على جهازك

```bash
npm install
cp .env.example .env
```

بعدين افتح `.env` وغيّر:

| المتغير | المطلوب |
|---|---|
| `JWT_SECRET` | مفتاح عشوائي. اعمله بـ: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` |
| `ADMIN_EMAIL` | الإيميل اللي هتدخل بيه لوحة التحكم |
| `ADMIN_PASSWORD` | الباسورد بتاعك (قوي) |

وبعدين:

```bash
npm start
```

- الموقع: `http://localhost:3000`
- لوحة التحكم: `http://localhost:3000/admin.html`

---

## الرفع على سيرفر (VPS)

```bash
# على السيرفر
git clone <رابط-المستودع> informa && cd informa
npm install --omit=dev
cp .env.example .env    # وغيّر القيم زي فوق

# شغّله بـ pm2 عشان يفضل شغال ويرجع لوحده لو وقع
npm install -g pm2
pm2 start server.js --name informa
pm2 save && pm2 startup
```

بعدين اعمل Nginx reverse proxy على البورت 3000 وفعّل SSL بـ certbot.

> **مهم:** GitHub Pages مبيشغّلش Node، فالموقع لازم يبقى على سيرفر حقيقي (VPS أو Render أو أي استضافة Node).
> لو عاوز تسيب الصفحات على GitHub Pages والـ API لوحده: حط لينك السيرفر في `apiBase` جوه `public/config.js`،
> وحط دومين الصفحات في `CORS_ORIGIN` جوه `.env`.

---

## الملفات

| الملف | الوظيفة |
|---|---|
| `server.js` | الـ API كله + تقديم صفحات الموقع |
| `public/config.js` | لينك الـ API + رقم الواتساب + الباقات (عدّلها من هنا) |
| `public/index.html` | الصفحة الرئيسية |
| `public/checkout.html` | تسجيل العميل (إيميل + باسورد من اختياره) |
| `public/admin.html` | لوحة التحكم — الطلبات وزرار ✓ |
| `public/access.html` | دخول الأعضاء |
| `public/videos.html` | مكتبة الفيديوهات (للأعضاء المفعّلين بس) |
| `data/informa.db` | قاعدة البيانات (بتتعمل لوحدها، متترفعش على git) |

---

## صور قبل وبعد

في `public/index.html` فيه قسم `id="results"` فيه 3 كروت، كل كارت مربعين (قبل / بعد).
اعمل فولدر `public/images` وحط فيه صور عملائك الحقيقيين (بإذنهم)، وبعدين استبدل
كل مربع رمادي بالسطر ده:

```html
<img src="images/before-1.jpg" alt="قبل" class="w-full h-full object-cover">
```

ومتنساش تغيّر "اسم العضو" و "النتيجة في كام شهر" تحت كل كارت.

---

## التمارين والفيديوهات

`public/videos.html` فيه 12 تمرين، كل واحد برسمة توضح الحركة + العدّات + نصيحة أداء.
لما تجيب الفيديوهات، فوق كل كارت فيه كومنت `<!-- ضع فيديو ... هنا بدل الرسمة -->`.
استبدل الـ `<svg>` بواحد من دول:

```html
<!-- يوتيوب -->
<iframe class="w-full aspect-video" src="https://www.youtube.com/embed/VIDEO_ID" allowfullscreen></iframe>

<!-- ملف فيديو عندك -->
<video class="w-full aspect-video" controls src="videos/bench-press.mp4"></video>
```

---

## الـ API

| الراوت | الوصف |
|---|---|
| `POST /api/signup` | تسجيل طلب جديد `{name, phone, email, password, planId}` |
| `POST /api/login` | دخول العضو → توكن |
| `GET /api/me` | بيانات العضو (بيتأكد إن الاشتراك لسه شغال) |
| `POST /api/admin/login` | دخول اللوحة → توكن أدمن |
| `GET /api/admin/members` | كل الأعضاء والطلبات |
| `POST /api/admin/members/:id/activate` | تفعيل / تجديد `{months}` |
| `POST /api/admin/members/:id/disable` | إيقاف عضو |
| `DELETE /api/admin/members/:id` | حذف عضو |

---

## ربط Paymob (اختياري، لما تجهز)

دلوقتي التفعيل يدوي بضغطة ✓. لما تجهز مفاتيح Paymob، ضيف في `server.js` راوت
بيعمل payment key من مفتاحك السري، وبعد ما Paymob يأكد الدفع (callback) نادِ نفس
دالة التفعيل بتاعة `/api/admin/members/:id/activate` — وساعتها الاشتراك هيتفعّل لوحده
من غير ما تدوس ✓.

---

## ملاحظات أمان

- `.env` و `data/` مستثنيين من git — متترفعش أبداً على GitHub.
- الباسوردات متخزنة hashed بـ bcrypt.
- غيّر `JWT_SECRET` و `ADMIN_PASSWORD` قبل أي رفع حقيقي.
- شغّل الموقع على HTTPS (certbot) عشان الباسوردات متعديش على النت بدون تشفير.


---

## محتاج من حسين قبل النشر

| الحاجة | مكانها |
|---|---|
| رقم الواتساب | `public/config.js` → `whatsapp` (بصيغة `201xxxxxxxxx`) — دلوقتي فيه رقم مؤقت لازم يتغيّر |
| صور قبل/بعد لمتدربين (بإذنهم) | قسم `#results` في `index.html` — عنده هايلايت Transformations على انستجرام |
| الأسعار الحقيقية | 3 أماكن لازم تتطابق: `index.html` (قسم الأسعار) + `public/config.js` + `server.js` |
| فيديوهات التمارين | `public/videos.html` — فوق كل رسمة كومنت بمكان الفيديو |
| لينكات السوشيال | الفوتر في `index.html` (انستجرام متظبط، الباقي لسه `#`) |
| بيانات دخول اللوحة | `.env` → `ADMIN_EMAIL` و `ADMIN_PASSWORD` |
